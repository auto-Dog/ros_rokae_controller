计划改动：
src\rob_moveit_pack\rob_control中：
1. rob_comm用ROKAE script接收信息，用msg的publish方法反馈
2. rob_control用ROKAE script执行操作
3. 将示例中的L_arm和R_arm改为各个关节